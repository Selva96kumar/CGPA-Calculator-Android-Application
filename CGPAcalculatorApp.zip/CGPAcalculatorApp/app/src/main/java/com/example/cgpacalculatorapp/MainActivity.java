package com.example.cgpacalculatorapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etSubject1Grade, etSubject1Credits;
    private EditText etSubject2Grade, etSubject2Credits;
    private EditText etSubject3Grade, etSubject3Credits;
    private EditText etSubject4Grade, etSubject4Credits;
    private EditText etSubject5Grade, etSubject5Credits;
    private EditText etSubject6Grade, etSubject6Credits;
    private EditText etSubject7Grade, etSubject7Credits;
    private EditText etSubject8Grade, etSubject8Credits;
    private EditText etTotalCredits;
    private Button btnCalculateCGPA, btnReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize EditText fields
        etSubject1Grade = findViewById(R.id.et_subject1_grade);
        etSubject1Credits = findViewById(R.id.et_subject1_credits);
        etSubject2Grade = findViewById(R.id.et_subject2_grade);
        etSubject2Credits = findViewById(R.id.et_subject2_credits);
        etSubject3Grade = findViewById(R.id.et_subject3_grade);
        etSubject3Credits = findViewById(R.id.et_subject3_credits);
        etSubject4Grade = findViewById(R.id.et_subject4_grade);
        etSubject4Credits = findViewById(R.id.et_subject4_credits);
        etSubject5Grade = findViewById(R.id.et_subject5_grade);
        etSubject5Credits = findViewById(R.id.et_subject5_credits);
        etSubject6Grade = findViewById(R.id.et_subject6_grade);
        etSubject6Credits = findViewById(R.id.et_subject6_credits);
        etSubject7Grade = findViewById(R.id.et_subject7_grade);
        etSubject7Credits = findViewById(R.id.et_subject7_credits);
        etSubject8Grade = findViewById(R.id.et_subject8_grade);
        etSubject8Credits = findViewById(R.id.et_subject8_credits);
        etTotalCredits = findViewById(R.id.et_total_credits);

        // Initialize Buttons
        btnCalculateCGPA = findViewById(R.id.btn_calculate_cgpa);
        btnReset = findViewById(R.id.btn_reset);

        // Set up button click listeners
        btnCalculateCGPA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateCGPA();
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetFields();
            }
        });
    }

    private void calculateCGPA() {
        try {
            double grade1 = Double.parseDouble(etSubject1Grade.getText().toString());
            double credits1 = Double.parseDouble(etSubject1Credits.getText().toString());
            double grade2 = Double.parseDouble(etSubject2Grade.getText().toString());
            double credits2 = Double.parseDouble(etSubject2Credits.getText().toString());
            double grade3 = Double.parseDouble(etSubject3Grade.getText().toString());
            double credits3 = Double.parseDouble(etSubject3Credits.getText().toString());
            double grade4 = Double.parseDouble(etSubject4Grade.getText().toString());
            double credits4 = Double.parseDouble(etSubject4Credits.getText().toString());
            double grade5 = Double.parseDouble(etSubject5Grade.getText().toString());
            double credits5 = Double.parseDouble(etSubject5Credits.getText().toString());
            double grade6 = Double.parseDouble(etSubject6Grade.getText().toString());
            double credits6 = Double.parseDouble(etSubject6Credits.getText().toString());
            double grade7 = Double.parseDouble(etSubject7Grade.getText().toString());
            double credits7 = Double.parseDouble(etSubject7Credits.getText().toString());
            double grade8 = Double.parseDouble(etSubject8Grade.getText().toString());
            double credits8 = Double.parseDouble(etSubject8Credits.getText().toString());

            double totalCredits = Double.parseDouble(etTotalCredits.getText().toString());

            double totalPoints = (grade1 * credits1) + (grade2 * credits2) + (grade3 * credits3) +
                    (grade4 * credits4) + (grade5 * credits5) + (grade6 * credits6) +
                    (grade7 * credits7) + (grade8 * credits8);

            double cgpa = totalPoints / totalCredits;

            Toast.makeText(this, "CGPA: " + cgpa, Toast.LENGTH_LONG).show();

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_LONG).show();
        }
    }

    private void resetFields() {
        etSubject1Grade.setText("");
        etSubject1Credits.setText("");
        etSubject2Grade.setText("");
        etSubject2Credits.setText("");
        etSubject3Grade.setText("");
        etSubject3Credits.setText("");
        etSubject4Grade.setText("");
        etSubject4Credits.setText("");
        etSubject5Grade.setText("");
        etSubject5Credits.setText("");
        etSubject6Grade.setText("");
        etSubject6Credits.setText("");
        etSubject7Grade.setText("");
        etSubject7Credits.setText("");
        etSubject8Grade.setText("");
        etSubject8Credits.setText("");
        etTotalCredits.setText("");
    }
}
